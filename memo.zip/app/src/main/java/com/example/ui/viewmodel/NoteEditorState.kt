package com.example.ui.viewmodel

data class NoteEditorState(
    val id: String? = null,
    val title: String = "",
    val content: String = "",
    val tags: String = "",
    val folder: String = "Personal",
    val colorHex: String = "#00F5D4",
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val isMarkdownPreview: Boolean = false,
    val encryptionKeyId: String = "AndroidKeyStore:cloudmemo_notes_master_key",
    val encryptionAlgorithm: String = "AES-256-GCM",
    val revision: Long = 1L,
    val lastSavedText: String = "All changes saved to cloud"
)
