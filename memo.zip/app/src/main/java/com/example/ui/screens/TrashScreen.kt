package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NoteEntity
import com.example.data.repository.SyncState
import com.example.ui.components.CloudMemoTopAppBar
import com.example.ui.components.CrystalGlassButton
import com.example.ui.components.CrystalGlassCard
import com.example.ui.theme.EmeraldOnline
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianVoid
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.TextWhitePrimary

@Composable
fun TrashScreen(
    trashedNotes: List<NoteEntity>,
    onRestoreNote: (String) -> Unit,
    onPermanentDeleteNote: (String) -> Unit,
    syncState: SyncState,
    onTriggerSync: () -> Unit,
    onNavigateBack: (() -> Unit)? = null
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ObsidianVoid)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            CloudMemoTopAppBar(
                title = "Trash",
                onNavigateBack = onNavigateBack,
                syncState = syncState,
                onTriggerSync = onTriggerSync
            )

            if (trashedNotes.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = null,
                            tint = TextTertiary,
                            modifier = Modifier.size(54.dp)
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Trash is Empty",
                            color = TextWhitePrimary,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Deleted notes will appear here before permanent removal",
                            color = TextMutedSecondary,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .weight(1f),
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 112.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(trashedNotes, key = { it.id }) { note ->
                        CrystalGlassCard(
                            modifier = Modifier.fillMaxWidth(),
                            accentColor = Color(0xFFEF4444)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = note.decryptedTitleCache.ifBlank { "Untitled Note" },
                                    color = TextWhitePrimary,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                if (note.decryptedContentCache.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = note.decryptedContentCache,
                                        color = TextMutedSecondary,
                                        fontSize = 13.sp,
                                        maxLines = 2
                                    )
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    CrystalGlassButton(
                                        onClick = { onRestoreNote(note.id) },
                                        accentColor = EmeraldOnline,
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.Restore, contentDescription = null, tint = EmeraldOnline, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Restore", color = EmeraldOnline, fontSize = 12.sp)
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    CrystalGlassButton(
                                        onClick = { onPermanentDeleteNote(note.id) },
                                        accentColor = Color(0xFFEF4444),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteForever, contentDescription = null, tint = Color(0xFFEF4444), modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Delete", color = Color(0xFFEF4444), fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
