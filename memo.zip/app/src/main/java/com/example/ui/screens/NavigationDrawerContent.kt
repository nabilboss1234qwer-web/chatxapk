package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AnimatedAestheticLogo
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianElevated
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextWhitePrimary
import com.example.ui.viewmodel.AppScreen

@Composable
fun NavigationDrawerContent(
    currentScreen: AppScreen,
    onNavigate: (AppScreen) -> Unit,
    userEmail: String?,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxHeight()
            .fillMaxWidth(0.78f)
            .background(ObsidianElevated)
            .border(1.dp, GlassBorder)
            .padding(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            Spacer(modifier = Modifier.height(24.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                AnimatedAestheticLogo(size = 40.dp)
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "CloudMemo",
                        color = TextWhitePrimary,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = userEmail ?: "Encrypted Vault",
                        color = TextMutedSecondary,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    DrawerItem(
                        icon = Icons.Default.Home,
                        label = "Notes",
                        isSelected = currentScreen == AppScreen.HOME,
                        onClick = {
                            onNavigate(AppScreen.HOME)
                            onClose()
                        }
                    )
                }
                item {
                    DrawerItem(
                        icon = Icons.Default.Search,
                        label = "Search Notes",
                        isSelected = currentScreen == AppScreen.SEARCH,
                        onClick = {
                            onNavigate(AppScreen.SEARCH)
                            onClose()
                        }
                    )
                }
                item {
                    DrawerItem(
                        icon = Icons.Default.Folder,
                        label = "Folders & Tags",
                        isSelected = currentScreen == AppScreen.FOLDERS_TAGS,
                        onClick = {
                            onNavigate(AppScreen.FOLDERS_TAGS)
                            onClose()
                        }
                    )
                }
                item {
                    DrawerItem(
                        icon = Icons.Default.Delete,
                        label = "Trash",
                        isSelected = currentScreen == AppScreen.TRASH,
                        onClick = {
                            onNavigate(AppScreen.TRASH)
                            onClose()
                        }
                    )
                }
                item {
                    DrawerItem(
                        icon = Icons.Default.Sync,
                        label = "Sync Status",
                        isSelected = currentScreen == AppScreen.SYNC_STATUS,
                        onClick = {
                            onNavigate(AppScreen.SYNC_STATUS)
                            onClose()
                        }
                    )
                }
                item {
                    DrawerItem(
                        icon = Icons.Default.Settings,
                        label = "Settings",
                        isSelected = currentScreen == AppScreen.SETTINGS,
                        onClick = {
                            onNavigate(AppScreen.SETTINGS)
                            onClose()
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun DrawerItem(
    icon: ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val bgColor = if (isSelected) NeonCyan.copy(alpha = 0.15f) else Color.Transparent
    val contentColor = if (isSelected) NeonCyan else TextMutedSecondary

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(bgColor)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(imageVector = icon, contentDescription = label, tint = contentColor, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(14.dp))
        Text(
            text = label,
            color = if (isSelected) TextWhitePrimary else TextMutedSecondary,
            fontSize = 14.sp,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}
