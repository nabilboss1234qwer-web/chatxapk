package com.example.ui.viewmodel

enum class AppScreen {
    SPLASH,
    TERMS_OF_SERVICE,
    PRIVACY_POLICY,
    ONBOARDING,
    LOGIN,
    VERIFY_EMAIL,
    VERIFY_MAGIC_LINK,
    HOME,
    NOTE_EDITOR,
    SEARCH,
    FOLDERS_TAGS,
    TRASH,
    SYNC_STATUS,
    DEVICES,
    SETTINGS,
    ACCOUNT,
    SHARE_NOTE,
    PIN_SETUP,
    PIN_LOCK
}
