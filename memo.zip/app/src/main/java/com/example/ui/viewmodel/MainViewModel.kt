package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.crypto.KeystoreHelper
import com.example.data.local.AppDatabase
import com.example.data.model.AccountExportDto
import com.example.data.model.DeviceDto
import com.example.data.model.NoteEntity
import com.example.data.model.ShareItemDto
import com.example.data.model.UserProfileDto
import com.example.data.network.CloudMemoApiService
import com.example.data.network.SessionManager
import com.example.data.repository.AuthRepository
import com.example.data.repository.NoteRepository
import com.example.data.repository.SyncState
import com.example.data.security.VaultLockManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Stack

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val sessionManager = SessionManager(application)
    private val keystoreHelper = KeystoreHelper(application)
    private val apiService = CloudMemoApiService(sessionManager)
    private val database = AppDatabase.getInstance(application)
    val vaultLockManager = VaultLockManager(application)

    val authRepository = AuthRepository(sessionManager, apiService, keystoreHelper)
    val noteRepository = NoteRepository(database, keystoreHelper, apiService, sessionManager)

    // Note display layout preference
    private val _noteDisplayLayout = MutableStateFlow(
        com.example.ui.model.NoteDisplayLayout.fromId(sessionManager.noteDisplayLayout)
    )
    val noteDisplayLayout: StateFlow<com.example.ui.model.NoteDisplayLayout> = _noteDisplayLayout.asStateFlow()

    // Navigation Stack
    private val screenStack = Stack<AppScreen>()
    private val _currentScreen = MutableStateFlow<AppScreen>(
        when {
            !sessionManager.isTosAccepted -> AppScreen.TERMS_OF_SERVICE
            !sessionManager.isLoggedIn -> AppScreen.LOGIN
            vaultLockManager.isVaultLockEnabled -> AppScreen.PIN_LOCK
            else -> AppScreen.HOME
        }
    )
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    // Notes & Data flows
    val notes: StateFlow<List<NoteEntity>> = noteRepository.notes.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val trashedNotes: StateFlow<List<NoteEntity>> = noteRepository.trashedNotes.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val pendingSyncCount: StateFlow<Int> = noteRepository.pendingSyncCount.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        0
    )

    // Sync State
    private val _syncState = MutableStateFlow<SyncState>(SyncState.Synced("Synced to Cloud"))
    val syncState: StateFlow<SyncState> = _syncState.asStateFlow()

    private var autoSaveJob: Job? = null

    init {
        viewModelScope.launch {
            try {
                pendingSyncCount.collect { count ->
                    if (count > 0 && _syncState.value !is SyncState.Syncing) {
                        _syncState.value = SyncState.Pending(count, "Saved Locally")
                    } else if (count == 0 && _syncState.value is SyncState.Pending) {
                        _syncState.value = SyncState.Synced("Synced to Cloud")
                    }
                }
            } catch (e: Exception) {
                // Ignore or log
            }
        }
        if (sessionManager.isLoggedIn) {
            try {
                loadUserProfile()
                triggerManualSync()
            } catch (e: Exception) {
                // Graceful offline fallback
            }
        }
    }

    private fun scheduleAutoSave() {
        autoSaveJob?.cancel()
        autoSaveJob = viewModelScope.launch {
            delay(1500L)
            saveCurrentNote(isManual = false)
        }
    }

    // Auth State
    val isLoggedIn: Boolean get() = sessionManager.isLoggedIn
    val userEmail: String? get() = sessionManager.userEmail
    val userDisplayName: String? get() = sessionManager.userDisplayName
    val userId: String? get() = sessionManager.userId
    val userRole: String? get() = sessionManager.userRole

    // Note Editor State (SAFE NON-NULL INITIALIZATION TO PREVENT CRASHES)
    private val _editorState = MutableStateFlow(NoteEditorState())
    val editorState: StateFlow<NoteEditorState> = _editorState.asStateFlow()

    // Search & Filter
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _searchResults = MutableStateFlow<List<NoteEntity>>(emptyList())
    val searchResults: StateFlow<List<NoteEntity>> = _searchResults.asStateFlow()

    private val _selectedFilter = MutableStateFlow("All")
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    // Auth Inputs (FastAPI Integration)
    private val _authEmailInput = MutableStateFlow("")
    val authEmailInput: StateFlow<String> = _authEmailInput.asStateFlow()

    private val _authPasswordInput = MutableStateFlow("")
    val authPasswordInput: StateFlow<String> = _authPasswordInput.asStateFlow()

    private val _authDisplayNameInput = MutableStateFlow("")
    val authDisplayNameInput: StateFlow<String> = _authDisplayNameInput.asStateFlow()

    private val _isRegisterMode = MutableStateFlow(false)
    val isRegisterMode: StateFlow<Boolean> = _isRegisterMode.asStateFlow()

    private val _verificationCodeInput = MutableStateFlow("")
    val verificationCodeInput: StateFlow<String> = _verificationCodeInput.asStateFlow()

    private val _authLoading = MutableStateFlow(false)
    val authLoading: StateFlow<Boolean> = _authLoading.asStateFlow()

    private val _authResending = MutableStateFlow(false)
    val authResending: StateFlow<Boolean> = _authResending.asStateFlow()

    private val _authMessage = MutableStateFlow<String?>(null)
    val authMessage: StateFlow<String?> = _authMessage.asStateFlow()

    // Profile & Export
    private val _userProfile = MutableStateFlow<UserProfileDto?>(null)
    val userProfile: StateFlow<UserProfileDto?> = _userProfile.asStateFlow()

    private val _accountExportData = MutableStateFlow<AccountExportDto?>(null)
    val accountExportData: StateFlow<AccountExportDto?> = _accountExportData.asStateFlow()

    // Devices & Shares
    private val _devicesList = MutableStateFlow<List<DeviceDto>>(emptyList())
    val devicesList: StateFlow<List<DeviceDto>> = _devicesList.asStateFlow()

    private val _activeShares = MutableStateFlow<List<ShareItemDto>>(emptyList())
    val activeShares: StateFlow<List<ShareItemDto>> = _activeShares.asStateFlow()

    // Settings State
    private val _themeMode = MutableStateFlow(sessionManager.themeMode)
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _autoSync = MutableStateFlow(sessionManager.isAutoSyncEnabled)
    val autoSync: StateFlow<Boolean> = _autoSync.asStateFlow()

    // Snackbar notifications
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    val isTosAccepted: Boolean get() = sessionManager.isTosAccepted
    val acceptedTosVersion: String? get() = sessionManager.acceptedTosVersion

    fun acceptTermsOfService() {
        sessionManager.acceptTos()
        // Fresh install flow: Terms of Service -> Accept -> Backend Login
        navigateTo(AppScreen.LOGIN, clearStack = true)
    }

    fun setNoteDisplayLayout(layout: com.example.ui.model.NoteDisplayLayout) {
        sessionManager.noteDisplayLayout = layout.id
        _noteDisplayLayout.value = layout
    }

    fun navigateTo(screen: AppScreen, clearStack: Boolean = false) {
        // Enforce access control: Do not allow protected screens if ToS not accepted
        if (!sessionManager.isTosAccepted && screen != AppScreen.TERMS_OF_SERVICE && screen != AppScreen.PRIVACY_POLICY) {
            _currentScreen.value = AppScreen.TERMS_OF_SERVICE
            return
        }
        // Enforce authentication: Do not allow protected screens if not logged in
        val protectedScreens = setOf(
            AppScreen.HOME, AppScreen.NOTE_EDITOR, AppScreen.SEARCH,
            AppScreen.FOLDERS_TAGS, AppScreen.TRASH, AppScreen.SYNC_STATUS,
            AppScreen.DEVICES, AppScreen.SETTINGS, AppScreen.ACCOUNT,
            AppScreen.SHARE_NOTE, AppScreen.PIN_SETUP
        )
        if (screen in protectedScreens && !sessionManager.isLoggedIn) {
            _currentScreen.value = AppScreen.LOGIN
            return
        }

        if (clearStack) {
            screenStack.clear()
        } else {
            screenStack.push(_currentScreen.value)
        }
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        if (!screenStack.isEmpty()) {
            _currentScreen.value = screenStack.pop()
            return true
        }
        return false
    }

    fun showSnackbar(message: String) {
        _snackbarMessage.value = message
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }

    fun setAuthEmail(email: String) {
        _authEmailInput.value = email
    }

    fun setAuthPassword(password: String) {
        _authPasswordInput.value = password
    }

    fun setAuthDisplayName(name: String) {
        _authDisplayNameInput.value = name
    }

    fun toggleRegisterMode(isRegister: Boolean) {
        _isRegisterMode.value = isRegister
    }

    fun setVerificationCode(code: String) {
        _verificationCodeInput.value = code
    }

    fun submitAuth() {
        val email = _authEmailInput.value.trim()
        val password = _authPasswordInput.value
        val displayName = _authDisplayNameInput.value.trim().ifBlank { "CloudMemo User" }

        if (email.isBlank() || !email.contains("@")) {
            showSnackbar("Please enter a valid email address.")
            return
        }

        if (_isRegisterMode.value) {
            // Register flow (FastAPI Backend: password min 12 chars)
            if (password.length < 12) {
                showSnackbar("Password must be at least 12 characters long.")
                return
            }
            _authLoading.value = true
            viewModelScope.launch {
                val res = authRepository.register(email, password, displayName)
                _authLoading.value = false
                res.onSuccess { regResponse ->
                    showSnackbar(regResponse.message)
                    _verificationCodeInput.value = ""
                    navigateTo(AppScreen.VERIFY_EMAIL)
                }.onFailure { err ->
                    showSnackbar(err.message ?: "Registration failed.")
                }
            }
        } else {
            // Login flow
            if (password.isBlank()) {
                showSnackbar("Please enter your password.")
                return
            }
            _authLoading.value = true
            viewModelScope.launch {
                val deviceName = "Android Phone (${android.os.Build.MODEL})"
                val res = authRepository.login(email, password, deviceName)
                _authLoading.value = false
                res.onSuccess {
                    showSnackbar("Successfully signed in! Notes synchronized.")
                    loadUserProfile()
                    triggerManualSync()
                    navigateTo(AppScreen.HOME, clearStack = true)
                }.onFailure { err ->
                    val msg = err.message ?: "Authentication failed."
                    if (msg.contains("verify", ignoreCase = true) || msg.contains("verification", ignoreCase = true)) {
                        showSnackbar("Email verification required. Sending code...")
                        resendVerificationCode()
                        navigateTo(AppScreen.VERIFY_EMAIL)
                    } else {
                        showSnackbar(msg)
                    }
                }
            }
        }
    }

    fun verifyEmailCode() {
        val email = _authEmailInput.value.trim()
        val code = _verificationCodeInput.value.trim()

        if (code.length != 25) {
            showSnackbar("Verification code must be exactly 25 digits.")
            return
        }

        _authLoading.value = true
        viewModelScope.launch {
            val res = authRepository.verifyEmail(email, code)
            _authLoading.value = false
            res.onSuccess {
                showSnackbar("Email verified successfully! Vault unlocked.")
                loadUserProfile()
                triggerManualSync()
                navigateTo(AppScreen.HOME, clearStack = true)
            }.onFailure { err ->
                showSnackbar(err.message ?: "Verification failed. Please check the 25-digit code.")
            }
        }
    }

    fun resendVerificationCode() {
        val email = _authEmailInput.value.trim()
        if (email.isBlank() || !email.contains("@")) {
            showSnackbar("Please enter a valid email address.")
            return
        }

        _authResending.value = true
        viewModelScope.launch {
            val res = authRepository.resendCode(email)
            _authResending.value = false
            res.onSuccess { regResponse ->
                showSnackbar("A new 25-digit verification code has been dispatched to $email")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Failed to resend code.")
            }
        }
    }

    fun loadUserProfile() {
        if (!sessionManager.isLoggedIn) return
        viewModelScope.launch {
            val res = authRepository.getCurrentUser()
            res.onSuccess { profile ->
                _userProfile.value = profile
            }
        }
    }

    fun exportAccount() {
        viewModelScope.launch {
            val res = authRepository.exportAccount()
            res.onSuccess { exportDto ->
                _accountExportData.value = exportDto
                showSnackbar("Export successful for ${exportDto.userEmail}! Encrypted backup ready.")
            }.onFailure { err ->
                showSnackbar(err.message ?: "Failed to export account data.")
            }
        }
    }

    fun deleteAccount(password: String, onSuccess: () -> Unit) {
        if (password.isBlank()) {
            showSnackbar("Password is required to delete account.")
            return
        }
        viewModelScope.launch {
            val res = authRepository.deleteAccount(password)
            res.onSuccess {
                database.roomNoteDao().clearAll()
                database.roomPendingSyncDao().clearQueue()
                sessionManager.clearSession()
                showSnackbar("Account and all encrypted data permanently deleted.")
                onSuccess()
                navigateTo(AppScreen.LOGIN, clearStack = true)
            }.onFailure { err ->
                showSnackbar(err.message ?: "Account deletion failed. Check password.")
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            showSnackbar("Logged out successfully.")
            navigateTo(AppScreen.LOGIN, clearStack = true)
        }
    }

    // SAFE NOTE CREATION (FIXES CRASH: ALWAYS NON-NULL FIELDS)
    fun startNewNote() {
        _editorState.value = NoteEditorState(
            id = null,
            title = "",
            content = "",
            tags = "",
            folder = "Personal",
            colorHex = "#00F5D4",
            isPinned = false,
            isFavorite = false,
            isMarkdownPreview = false,
            lastSavedText = "Draft created"
        )
        navigateTo(AppScreen.NOTE_EDITOR)
    }

    fun openNoteForEdit(note: NoteEntity) {
        _editorState.value = NoteEditorState(
            id = note.id,
            title = note.decryptedTitleCache,
            content = note.decryptedContentCache,
            tags = note.decryptedTagsCache,
            folder = note.folder.ifBlank { "Personal" },
            colorHex = note.colorHex.ifBlank { "#00F5D4" },
            isPinned = note.isPinned,
            isFavorite = note.isFavorite,
            isMarkdownPreview = false,
            revision = note.revision,
            lastSavedText = "Synced to Cloud"
        )
        navigateTo(AppScreen.NOTE_EDITOR)
        loadSharesForNote(note.id)
    }

    fun updateEditorTitle(title: String) {
        _editorState.value = _editorState.value.copy(
            title = title,
            lastSavedText = "Saving to Room..."
        )
        scheduleAutoSave()
    }

    fun updateEditorContent(content: String) {
        _editorState.value = _editorState.value.copy(
            content = content,
            lastSavedText = "Saving to Room..."
        )
        scheduleAutoSave()
    }

    fun updateEditorTags(tags: String) {
        _editorState.value = _editorState.value.copy(tags = tags)
        scheduleAutoSave()
    }

    fun updateEditorFolder(folder: String) {
        _editorState.value = _editorState.value.copy(folder = folder)
        scheduleAutoSave()
    }

    fun updateEditorColor(colorHex: String) {
        _editorState.value = _editorState.value.copy(colorHex = colorHex)
        scheduleAutoSave()
    }

    fun toggleMarkdownPreview() {
        _editorState.value = _editorState.value.copy(
            isMarkdownPreview = !_editorState.value.isMarkdownPreview
        )
    }

    fun saveCurrentNote(isManual: Boolean = true, onSuccess: (() -> Unit)? = null) {
        val state = _editorState.value
        if (state.title.isBlank() && state.content.isBlank()) {
            if (isManual) showSnackbar("Note cannot be empty.")
            return
        }

        viewModelScope.launch {
            _syncState.value = SyncState.Syncing
            val noteId = noteRepository.saveNote(
                id = state.id,
                title = state.title.ifBlank { "Untitled" },
                content = state.content,
                tags = state.tags,
                folder = state.folder,
                colorHex = state.colorHex,
                isPinned = state.isPinned,
                isFavorite = state.isFavorite
            )
            val pCount = try {
                noteRepository.pendingSyncDao.getAllPending().size
            } catch (e: Exception) { 0 }

            if (pCount == 0) {
                _syncState.value = SyncState.Synced("Synced to Cloud")
                _editorState.value = _editorState.value.copy(
                    id = noteId,
                    lastSavedText = "Saved to Room & Synced to Cloud"
                )
            } else {
                _syncState.value = SyncState.Pending(pCount, "Saved Locally")
                _editorState.value = _editorState.value.copy(
                    id = noteId,
                    lastSavedText = "Auto-saved to Room Database"
                )
            }
            if (isManual) {
                showSnackbar("Note encrypted & persisted to Room database.")
            }
            onSuccess?.invoke()
        }
    }

    fun deleteCurrentNote() {
        val noteId = _editorState.value.id ?: return
        viewModelScope.launch {
            noteRepository.softDeleteNote(noteId)
            showSnackbar("Note moved to Trash.")
            navigateBack()
        }
    }

    fun togglePin(noteId: String, isPinned: Boolean) {
        viewModelScope.launch {
            noteRepository.togglePin(noteId, isPinned)
        }
    }

    fun toggleFavorite(noteId: String, isFavorite: Boolean) {
        viewModelScope.launch {
            noteRepository.toggleFavorite(noteId, isFavorite)
        }
    }

    fun restoreNote(noteId: String) {
        viewModelScope.launch {
            noteRepository.restoreNote(noteId)
            showSnackbar("Note restored from Trash.")
        }
    }

    fun permanentlyDeleteNote(noteId: String) {
        viewModelScope.launch {
            noteRepository.permanentDeleteNote(noteId)
            showSnackbar("Note permanently deleted.")
        }
    }

    fun onSearchQueryChanged(query: String) {
        _searchQuery.value = query
        viewModelScope.launch {
            _searchResults.value = noteRepository.searchLocalNotes(query)
        }
    }

    fun setFilter(filter: String) {
        _selectedFilter.value = filter
    }

    fun loadSharesForNote(noteId: String) {
        viewModelScope.launch {
            val res = noteRepository.listShares(noteId)
            res.onSuccess { list ->
                _activeShares.value = list
            }
        }
    }

    fun shareNote(recipientEmail: String, permission: String) {
        val noteId = _editorState.value.id ?: return
        viewModelScope.launch {
            val res = noteRepository.createShare(noteId, recipientEmail, permission)
            res.onSuccess { share ->
                _activeShares.value = _activeShares.value + share
                showSnackbar("Note shared with $recipientEmail")
            }.onFailure {
                showSnackbar("Failed to share note.")
            }
        }
    }

    fun revokeShare(shareId: String) {
        viewModelScope.launch {
            noteRepository.revokeShare(shareId)
            _activeShares.value = _activeShares.value.filter { it.shareId != shareId }
            showSnackbar("Sharing access revoked.")
        }
    }

    fun triggerManualSync() {
        if (!sessionManager.isLoggedIn) {
            showSnackbar("Authentication required to synchronize notes.")
            return
        }
        viewModelScope.launch {
            _syncState.value = SyncState.Syncing
            val res = noteRepository.syncNow()
            val remainingPending = try {
                noteRepository.pendingSyncDao.getAllPending().size
            } catch (e: Exception) { 0 }

            res.onSuccess {
                if (remainingPending == 0) {
                    _syncState.value = SyncState.Synced("Synced to Cloud")
                    showSnackbar("Cloud sync completed successfully.")
                } else {
                    _syncState.value = SyncState.Pending(remainingPending, "Saved Locally")
                    showSnackbar("$remainingPending note(s) pending sync to cloud.")
                }
            }.onFailure {
                val count = if (remainingPending > 0) remainingPending else 1
                _syncState.value = SyncState.Pending(count, "Saved Locally")
                showSnackbar("Sync failed. Notes saved securely on device in Room.")
            }
        }
    }

    fun loadDevices() {
        viewModelScope.launch {
            val res = authRepository.listDevices()
            res.onSuccess { list ->
                _devicesList.value = list
            }
        }
    }

    fun revokeDevice(deviceId: String) {
        viewModelScope.launch {
            authRepository.revokeDevice(deviceId)
            _devicesList.value = _devicesList.value.filter { it.deviceId != deviceId }
            showSnackbar("Device access revoked.")
        }
    }

    fun updateThemeMode(mode: String) {
        sessionManager.themeMode = mode
        _themeMode.value = mode
    }

    fun toggleAutoSync(enabled: Boolean) {
        sessionManager.isAutoSyncEnabled = enabled
        _autoSync.value = enabled
    }

    fun getDevicePublicKeyFingerprint(): String {
        return keystoreHelper.getDevicePublicKeyFingerprint()
    }

    fun getDeviceId(): String {
        return keystoreHelper.deviceId
    }

    fun setVaultPin(pin: String, enableBiometrics: Boolean) {
        vaultLockManager.savePin(pin)
        vaultLockManager.isBiometricEnabled = enableBiometrics
        showSnackbar("Vault Lock & 4-Digit PIN Enabled!")
        navigateTo(AppScreen.SETTINGS, clearStack = true)
    }

    fun disableVaultPinLock() {
        vaultLockManager.disableVaultLock()
        showSnackbar("Vault Lock disabled.")
    }

    fun verifyVaultPin(pin: String): Boolean {
        return vaultLockManager.verifyPin(pin)
    }

    fun onVaultUnlocked() {
        showSnackbar("Vault Unlocked!")
        navigateTo(if (sessionManager.isLoggedIn) AppScreen.HOME else AppScreen.SPLASH, clearStack = true)
    }
}
