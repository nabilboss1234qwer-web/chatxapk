package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderHighlight
import com.example.ui.theme.HotPinkAccent
import com.example.ui.theme.NeonCyan

@Composable
fun AnimatedAestheticLogo(
    modifier: Modifier = Modifier,
    size: Dp = 36.dp
) {
    val infiniteTransition = rememberInfiniteTransition(label = "aesthetic_logo_anim")

    // Smooth continuous rotation for ring
    val ringRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ring_rotation"
    )

    // Gentle breathing pulse scale
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    // Shimmering specular shift
    val shimmerOffset by infiniteTransition.animateFloat(
        initialValue = -100f,
        targetValue = 300f,
        animationSpec = infiniteRepeatable(
            animation = tween(2500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "shimmer_offset"
    )

    Box(
        modifier = modifier
            .size(size)
            .scale(pulseScale),
        contentAlignment = Alignment.Center
    ) {
        // Outer animated rotating crystal ring
        Box(
            modifier = Modifier
                .size(size)
                .rotate(ringRotation)
                .clip(CircleShape)
                .border(
                    width = (size.value * 0.05f).dp.coerceAtLeast(1.dp),
                    brush = Brush.sweepGradient(
                        colors = listOf(
                            NeonCyan,
                            ElectricViolet,
                            HotPinkAccent,
                            NeonCyan
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Inner glowing glass core canvas
        Canvas(
            modifier = Modifier
                .size((size.value * 0.82f).dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            ElectricViolet.copy(alpha = 0.35f),
                            Color(0xFF090D18)
                        )
                    )
                )
        ) {
            val width = this.size.width
            val height = this.size.height

            // Aesthetic 3D Crystal Cloud Path
            val path = Path().apply {
                val cx = width * 0.5f
                val cy = height * 0.55f
                val r = width * 0.22f

                moveTo(cx - r * 1.2f, cy)
                cubicTo(
                    cx - r * 1.5f, cy - r * 0.6f,
                    cx - r * 0.8f, cy - r * 1.3f,
                    cx - r * 0.2f, cy - r * 1.1f
                )
                cubicTo(
                    cx + r * 0.3f, cy - r * 1.6f,
                    cx + r * 1.2f, cy - r * 1.0f,
                    cx + r * 1.1f, cy - r * 0.2f
                )
                cubicTo(
                    cx + r * 1.5f, cy + r * 0.2f,
                    cx + r * 1.1f, cy + r * 0.9f,
                    cx + r * 0.5f, cy + r * 0.8f
                )
                cubicTo(
                    cx - r * 0.2f, cy + r * 0.9f,
                    cx - r * 1.0f, cy + r * 0.8f,
                    cx - r * 1.2f, cy
                )
                close()
            }

            // Draw filled gradient cloud
            drawPath(
                path = path,
                brush = Brush.linearGradient(
                    colors = listOf(
                        NeonCyan,
                        ElectricViolet
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(width, height)
                )
            )

            // Draw aesthetic glowing bevel outline
            drawPath(
                path = path,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.8f),
                        GlassBorderHighlight,
                        Color.Transparent
                    ),
                    start = Offset(shimmerOffset, 0f),
                    end = Offset(shimmerOffset + width * 0.5f, height)
                ),
                style = Stroke(width = width * 0.05f)
            )
        }
    }
}
