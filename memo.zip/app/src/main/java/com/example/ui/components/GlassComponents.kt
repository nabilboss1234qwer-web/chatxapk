package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlassBorder
import com.example.ui.theme.GlassBorderHighlight
import com.example.ui.theme.GlassCardBackground
import com.example.ui.theme.GlassSpecularReflection
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMutedSecondary
import com.example.ui.theme.TextWhitePrimary

@Composable
fun CrystalGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(18.dp),
    accentColor: Color? = null,
    onClick: (() -> Unit)? = null,
    content: @Composable () -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed && onClick != null) 0.98f else 1.0f,
        animationSpec = spring(),
        label = "card_scale"
    )

    val borderBrush = Brush.linearGradient(
        colors = listOf(
            (accentColor ?: NeonCyan).copy(alpha = 0.45f),
            GlassBorder,
            GlassSpecularReflection,
            (accentColor ?: ElectricViolet).copy(alpha = 0.25f)
        ),
        start = Offset(0f, 0f),
        end = Offset(400f, 400f)
    )

    val glassBackgroundBrush = Brush.verticalGradient(
        colors = listOf(
            Color(0x331E293B),
            Color(0x1F0F172A),
            Color(0x2E090D18)
        )
    )

    Box(
        modifier = modifier
            .scale(scale)
            .shadow(
                elevation = 8.dp,
                shape = shape,
                ambientColor = (accentColor ?: NeonCyan).copy(alpha = 0.2f),
                spotColor = Color.Black
            )
            .clip(shape)
            .background(glassBackgroundBrush)
            .border(width = 1.dp, brush = borderBrush, shape = shape)
            .drawBehind {
                drawLine(
                    color = Color.White.copy(alpha = 0.15f),
                    start = Offset(20f, 1f),
                    end = Offset(size.width - 20f, 1f),
                    strokeWidth = 1.5f
                )
            }
            .then(
                if (onClick != null) {
                    Modifier.clickable(
                        interactionSource = interactionSource,
                        indication = null,
                        onClick = onClick
                    )
                } else Modifier
            )
    ) {
        content()
    }
}

@Composable
fun CrystalGlassButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    accentColor: Color = NeonCyan,
    enabled: Boolean = true,
    contentPadding: PaddingValues = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
    content: @Composable RowScope.() -> Unit
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.96f else 1.0f,
        animationSpec = spring(),
        label = "btn_scale"
    )

    val buttonBrush = Brush.horizontalGradient(
        colors = listOf(
            accentColor.copy(alpha = if (enabled) 0.25f else 0.1f),
            ElectricViolet.copy(alpha = if (enabled) 0.20f else 0.08f)
        )
    )

    val borderBrush = Brush.linearGradient(
        colors = listOf(
            accentColor.copy(alpha = if (enabled) 0.8f else 0.3f),
            GlassBorderHighlight.copy(alpha = 0.4f),
            Color.White.copy(alpha = 0.2f)
        )
    )

    Box(
        modifier = modifier
            .scale(scale)
            .shadow(
                elevation = if (isPressed) 2.dp else 6.dp,
                shape = shape,
                spotColor = accentColor.copy(alpha = 0.3f)
            )
            .clip(shape)
            .background(buttonBrush)
            .border(width = 1.2.dp, brush = borderBrush, shape = shape)
            .clickable(
                enabled = enabled,
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .defaultMinSize(minHeight = 44.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            modifier = Modifier.padding(contentPadding),
            verticalAlignment = Alignment.CenterVertically,
            content = content
        )
    }
}

@Composable
fun CrystalGlassChip(
    text: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    activeColor: Color = NeonCyan
) {
    val chipShape = RoundedCornerShape(12.dp)
    val backgroundBrush = if (isSelected) {
        Brush.horizontalGradient(
            colors = listOf(
                activeColor.copy(alpha = 0.25f),
                ElectricViolet.copy(alpha = 0.20f)
            )
        )
    } else {
        Brush.horizontalGradient(
            colors = listOf(
                Color(0x221E293B),
                Color(0x180F172A)
            )
        )
    }

    val borderBrush = if (isSelected) {
        Brush.linearGradient(
            colors = listOf(
                activeColor.copy(alpha = 0.8f),
                GlassBorderHighlight
            )
        )
    } else {
        Brush.linearGradient(
            colors = listOf(
                GlassBorder,
                Color.White.copy(alpha = 0.08f)
            )
        )
    }

    Box(
        modifier = modifier
            .clip(chipShape)
            .background(backgroundBrush)
            .border(width = 1.dp, brush = borderBrush, shape = chipShape)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = text,
            color = if (isSelected) activeColor else TextMutedSecondary,
            fontSize = 13.sp
        )
    }
}
