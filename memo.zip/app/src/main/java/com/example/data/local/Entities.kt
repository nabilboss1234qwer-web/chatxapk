package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.NoteEntity
import com.example.data.model.PendingSyncEntity

@Entity(tableName = "notes")
data class NoteDbEntity(
    @PrimaryKey
    val id: String,
    val revision: Long = 1L,
    val serverVersion: Long = 1L,
    val titleCiphertext: String = "",
    val contentCiphertext: String = "",
    val decryptedTitleCache: String = "",
    val decryptedContentCache: String = "",
    val tagsCiphertext: String? = null,
    val decryptedTagsCache: String = "",
    val encryptionNonce: String = "",
    val encryptionKeyId: String = "AndroidKeyStore:cloudmemo_notes_master_key",
    val encryptionAlgorithm: String = "AES-256-GCM",
    val encryptionVersion: Int = 1,
    val folder: String = "Personal",
    val colorHex: String = "#00F5D4",
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedAt: String? = null,
    val createdAt: String = "",
    val updatedAt: String = "",
    val syncStatus: String = "SYNCED"
) {
    fun toDomain(): NoteEntity = NoteEntity(
        id = id,
        revision = revision,
        serverVersion = serverVersion,
        titleCiphertext = titleCiphertext,
        contentCiphertext = contentCiphertext,
        decryptedTitleCache = decryptedTitleCache,
        decryptedContentCache = decryptedContentCache,
        tagsCiphertext = tagsCiphertext,
        decryptedTagsCache = decryptedTagsCache,
        encryptionNonce = encryptionNonce,
        encryptionKeyId = encryptionKeyId,
        encryptionAlgorithm = encryptionAlgorithm,
        encryptionVersion = encryptionVersion,
        folder = folder,
        colorHex = colorHex,
        isPinned = isPinned,
        isFavorite = isFavorite,
        isDeleted = isDeleted,
        deletedAt = deletedAt,
        createdAt = createdAt,
        updatedAt = updatedAt,
        syncStatus = syncStatus
    )

    companion object {
        fun fromDomain(n: NoteEntity): NoteDbEntity = NoteDbEntity(
            id = n.id,
            revision = n.revision,
            serverVersion = n.serverVersion,
            titleCiphertext = n.titleCiphertext,
            contentCiphertext = n.contentCiphertext,
            decryptedTitleCache = n.decryptedTitleCache,
            decryptedContentCache = n.decryptedContentCache,
            tagsCiphertext = n.tagsCiphertext,
            decryptedTagsCache = n.decryptedTagsCache,
            encryptionNonce = n.encryptionNonce,
            encryptionKeyId = n.encryptionKeyId,
            encryptionAlgorithm = n.encryptionAlgorithm,
            encryptionVersion = n.encryptionVersion,
            folder = n.folder,
            colorHex = n.colorHex,
            isPinned = n.isPinned,
            isFavorite = n.isFavorite,
            isDeleted = n.isDeleted,
            deletedAt = n.deletedAt,
            createdAt = n.createdAt,
            updatedAt = n.updatedAt,
            syncStatus = n.syncStatus
        )
    }
}

@Entity(tableName = "pending_sync_queue")
data class PendingSyncDbEntity(
    @PrimaryKey
    val operationId: String,
    val noteId: String,
    val type: String,
    val expectedRevision: Long,
    val titleCiphertext: String? = null,
    val contentCiphertext: String? = null,
    val tagsCiphertext: String? = null,
    val nonce: String? = null,
    val keyId: String? = null,
    val folder: String? = null,
    val colorHex: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val retryCount: Int = 0
) {
    fun toDomain(): PendingSyncEntity = PendingSyncEntity(
        operationId = operationId,
        noteId = noteId,
        type = type,
        expectedRevision = expectedRevision,
        titleCiphertext = titleCiphertext,
        contentCiphertext = contentCiphertext,
        tagsCiphertext = tagsCiphertext,
        nonce = nonce,
        keyId = keyId,
        folder = folder,
        colorHex = colorHex,
        createdAt = createdAt,
        retryCount = retryCount
    )

    companion object {
        fun fromDomain(p: PendingSyncEntity): PendingSyncDbEntity = PendingSyncDbEntity(
            operationId = p.operationId,
            noteId = p.noteId,
            type = p.type,
            expectedRevision = p.expectedRevision,
            titleCiphertext = p.titleCiphertext,
            contentCiphertext = p.contentCiphertext,
            tagsCiphertext = p.tagsCiphertext,
            nonce = p.nonce,
            keyId = p.keyId,
            folder = p.folder,
            colorHex = p.colorHex,
            createdAt = p.createdAt,
            retryCount = p.retryCount
        )
    }
}
