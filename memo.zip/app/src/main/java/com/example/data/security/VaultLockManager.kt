package com.example.data.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.MessageDigest

class VaultLockManager(private val context: Context) {

    private val prefs = context.getSharedPreferences("cloudmemo_security_prefs", Context.MODE_PRIVATE)

    var isVaultLockEnabled: Boolean
        get() = prefs.getBoolean("is_vault_lock_enabled", false)
        set(value) = prefs.edit().putBoolean("is_vault_lock_enabled", value).apply()

    var isBiometricEnabled: Boolean
        get() = prefs.getBoolean("is_biometric_enabled", false)
        set(value) = prefs.edit().putBoolean("is_biometric_enabled", value).apply()

    private var savedPinHash: String?
        get() = prefs.getString("saved_pin_hash", null)
        set(value) = prefs.edit().putString("saved_pin_hash", value).apply()

    fun savePin(pin: String) {
        savedPinHash = hashPin(pin)
        isVaultLockEnabled = true
    }

    fun verifyPin(pin: String): Boolean {
        val currentHash = savedPinHash ?: return false
        return currentHash == hashPin(pin)
    }

    fun disableVaultLock() {
        savedPinHash = null
        isVaultLockEnabled = false
        isBiometricEnabled = false
    }

    private fun hashPin(pin: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun isBiometricAvailable(): Boolean {
        return try {
            val biometricManager = BiometricManager.from(context)
            biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
            ) == BiometricManager.BIOMETRIC_SUCCESS
        } catch (e: Exception) {
            false
        }
    }

    fun showBiometricPrompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        try {
            val executor = ContextCompat.getMainExecutor(activity)
            val biometricPrompt = BiometricPrompt(
                activity,
                executor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        super.onAuthenticationSucceeded(result)
                        onSuccess()
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        super.onAuthenticationError(errorCode, errString)
                        onError(errString.toString())
                    }

                    override fun onAuthenticationFailed() {
                        super.onAuthenticationFailed()
                        onError("Fingerprint/Face not recognized. Try again.")
                    }
                }
            )

            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("CloudMemo Vault Unlock")
                .setSubtitle("Authenticate using Fingerprint or Face unlock")
                .setNegativeButtonText("Use PIN")
                .build()

            biometricPrompt.authenticate(promptInfo)
        } catch (e: Exception) {
            onError(e.message ?: "Biometric prompt unavailable")
        }
    }
}
