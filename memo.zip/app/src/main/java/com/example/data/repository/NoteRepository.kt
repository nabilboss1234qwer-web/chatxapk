package com.example.data.repository

import com.example.data.crypto.KeystoreHelper
import com.example.data.local.AppDatabase
import com.example.data.local.NoteDbEntity
import com.example.data.local.PendingSyncDbEntity
import com.example.data.model.ApiErrorDetail
import com.example.data.model.NoteEntity
import com.example.data.model.ShareItemDto
import com.example.data.model.TrashServerItemDto
import com.example.data.network.CloudMemoApiService
import com.example.data.network.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class NoteRepository(
    private val database: AppDatabase,
    private val keystoreHelper: KeystoreHelper,
    private val apiService: CloudMemoApiService,
    private val sessionManager: SessionManager
) {
    val noteDao = database.roomNoteDao()
    val pendingSyncDao = database.roomPendingSyncDao()

    val notes: Flow<List<NoteEntity>> = noteDao.getAllActiveNotesFlow().map { list -> list.map { it.toDomain() } }
    val trashedNotes: Flow<List<NoteEntity>> = noteDao.getTrashedNotesFlow().map { list -> list.map { it.toDomain() } }
    val pendingSyncCount: Flow<Int> = pendingSyncDao.getPendingCountFlow()

    private fun getCurrentIsoTime(): String {
        return SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date())
    }

    suspend fun getNoteById(noteId: String): NoteEntity? = noteDao.getNoteById(noteId)?.toDomain()

    suspend fun saveNote(
        id: String?,
        title: String,
        content: String,
        tags: String,
        folder: String,
        colorHex: String,
        isPinned: Boolean,
        isFavorite: Boolean
    ): String = withContext(Dispatchers.IO) {
        val now = getCurrentIsoTime()
        // FastAPI backend schema requires note_id minLength: 8
        val noteId = id?.ifBlank { null } ?: ("note_" + UUID.randomUUID().toString().replace("-", "").take(12))

        val existing = noteDao.getNoteById(noteId)
        val revision = (existing?.revision ?: 0L) + 1L

        val packedPayload = keystoreHelper.packNotePayload(
            title = title,
            content = content,
            tags = tags,
            folder = folder.ifBlank { "Personal" },
            colorHex = colorHex.ifBlank { "#00F5D4" },
            isPinned = isPinned,
            isFavorite = isFavorite
        )

        val enc = keystoreHelper.encryptText(packedPayload)

        val noteDbEntity = NoteDbEntity(
            id = noteId,
            revision = revision,
            serverVersion = existing?.serverVersion ?: 1L,
            titleCiphertext = enc.ciphertextBase64,
            contentCiphertext = enc.ciphertextBase64,
            decryptedTitleCache = title,
            decryptedContentCache = content,
            tagsCiphertext = null,
            decryptedTagsCache = tags,
            encryptionNonce = enc.nonceBase64,
            encryptionKeyId = enc.keyId,
            encryptionAlgorithm = enc.algorithm,
            encryptionVersion = enc.version,
            folder = folder.ifBlank { "Personal" },
            colorHex = colorHex.ifBlank { "#00F5D4" },
            isPinned = isPinned,
            isFavorite = isFavorite,
            isDeleted = false,
            deletedAt = null,
            createdAt = existing?.createdAt ?: now,
            updatedAt = now,
            syncStatus = "SAVED_LOCAL"
        )

        noteDao.insertOrUpdate(noteDbEntity)

        val op = PendingSyncDbEntity(
            operationId = "op_" + UUID.randomUUID().toString().take(8),
            noteId = noteId,
            type = if (existing == null) "CREATE" else "UPDATE",
            expectedRevision = revision,
            titleCiphertext = enc.ciphertextBase64,
            contentCiphertext = enc.ciphertextBase64,
            tagsCiphertext = null,
            nonce = enc.nonceBase64,
            keyId = enc.keyId,
            folder = folder,
            colorHex = colorHex
        )
        pendingSyncDao.enqueue(op)

        if (sessionManager.isLoggedIn) {
            try {
                if (existing == null) {
                    val res = apiService.createNote(
                        noteId = noteId,
                        encryptedPayload = enc.ciphertextBase64,
                        nonce = enc.nonceBase64,
                        keyVersion = 1,
                        clientVersion = revision
                    )
                    res.onSuccess { serverItem ->
                        noteDao.insertOrUpdate(
                            noteDbEntity.copy(
                                serverVersion = serverItem.serverVersion,
                                syncStatus = "SYNCED"
                            )
                        )
                        pendingSyncDao.removeByNoteId(noteId)
                    }
                } else {
                    val res = apiService.updateNote(
                        noteId = noteId,
                        encryptedPayload = enc.ciphertextBase64,
                        nonce = enc.nonceBase64,
                        keyVersion = 1,
                        clientVersion = revision
                    )
                    res.onSuccess { serverItem ->
                        noteDao.insertOrUpdate(
                            noteDbEntity.copy(
                                serverVersion = serverItem.serverVersion,
                                syncStatus = "SYNCED"
                            )
                        )
                        pendingSyncDao.removeByNoteId(noteId)
                    }
                }
            } catch (_: Exception) {}
        }

        noteId
    }

    suspend fun softDeleteNote(noteId: String) = withContext(Dispatchers.IO) {
        val now = getCurrentIsoTime()
        noteDao.softDelete(noteId, now)
        val op = PendingSyncDbEntity(
            operationId = "op_del_" + UUID.randomUUID().toString().take(8),
            noteId = noteId,
            type = "DELETE",
            expectedRevision = 0L
        )
        pendingSyncDao.enqueue(op)

        if (sessionManager.isLoggedIn) {
            try {
                val res = apiService.trashNote(noteId)
                if (res.isSuccess) {
                    pendingSyncDao.removeByOperationId(op.operationId)
                }
            } catch (_: Exception) {}
        }
    }

    suspend fun restoreNote(noteId: String) = withContext(Dispatchers.IO) {
        noteDao.restoreNote(noteId)
        if (sessionManager.isLoggedIn) {
            try {
                apiService.restoreTrashNote(noteId)
            } catch (_: Exception) {}
        }
    }

    suspend fun permanentDeleteNote(noteId: String) = withContext(Dispatchers.IO) {
        noteDao.deleteById(noteId)
        pendingSyncDao.removeByNoteId(noteId)
        if (sessionManager.isLoggedIn) {
            try {
                apiService.permanentDeleteTrashNote(noteId)
            } catch (_: Exception) {}
        }
    }

    suspend fun listTrashFromServer(): Result<List<TrashServerItemDto>> = withContext(Dispatchers.IO) {
        if (!sessionManager.isLoggedIn) return@withContext Result.success(emptyList())
        apiService.listTrash()
    }

    suspend fun togglePin(noteId: String, isPinned: Boolean) = withContext(Dispatchers.IO) {
        noteDao.setPinned(noteId, isPinned)
        val note = noteDao.getNoteById(noteId) ?: return@withContext
        saveNote(
            id = note.id,
            title = note.decryptedTitleCache,
            content = note.decryptedContentCache,
            tags = note.decryptedTagsCache,
            folder = note.folder,
            colorHex = note.colorHex,
            isPinned = isPinned,
            isFavorite = note.isFavorite
        )
    }

    suspend fun toggleFavorite(noteId: String, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        noteDao.setFavorite(noteId, isFavorite)
        val note = noteDao.getNoteById(noteId) ?: return@withContext
        saveNote(
            id = note.id,
            title = note.decryptedTitleCache,
            content = note.decryptedContentCache,
            tags = note.decryptedTagsCache,
            folder = note.folder,
            colorHex = note.colorHex,
            isPinned = note.isPinned,
            isFavorite = isFavorite
        )
    }

    suspend fun searchLocalNotes(query: String): List<NoteEntity> = withContext(Dispatchers.IO) {
        if (query.isBlank()) return@withContext emptyList()
        noteDao.searchLocalNotes(query).map { it.toDomain() }
    }

    suspend fun syncNow(): Result<String> = withContext(Dispatchers.IO) {
        if (!sessionManager.isLoggedIn) {
            return@withContext Result.failure(Exception("Authentication required to synchronize notes."))
        }

        try {
            // Step 1: Process local pending sync queue to backend
            val pendingList = pendingSyncDao.getAllPending()
            for (p in pendingList) {
                try {
                    when (p.type) {
                        "CREATE" -> {
                            val payload = p.contentCiphertext ?: ""
                            val nonce = p.nonce ?: ""
                            val res = apiService.createNote(
                                noteId = p.noteId,
                                encryptedPayload = payload,
                                nonce = nonce,
                                keyVersion = 1,
                                clientVersion = p.expectedRevision
                            )
                            if (res.isSuccess) {
                                pendingSyncDao.removeByOperationId(p.operationId)
                                noteDao.getNoteById(p.noteId)?.let { currentNote ->
                                    noteDao.insertOrUpdate(currentNote.copy(syncStatus = "SYNCED"))
                                }
                            } else {
                                val err = res.exceptionOrNull()
                                if (err is ApiErrorDetail && err.isConflict) {
                                    // Already exists on server, update it
                                    val updRes = apiService.updateNote(
                                        noteId = p.noteId,
                                        encryptedPayload = payload,
                                        nonce = nonce,
                                        keyVersion = 1,
                                        clientVersion = p.expectedRevision + 1
                                    )
                                    if (updRes.isSuccess) {
                                        pendingSyncDao.removeByOperationId(p.operationId)
                                    }
                                }
                            }
                        }
                        "UPDATE" -> {
                            val payload = p.contentCiphertext ?: ""
                            val nonce = p.nonce ?: ""
                            val res = apiService.updateNote(
                                noteId = p.noteId,
                                encryptedPayload = payload,
                                nonce = nonce,
                                keyVersion = 1,
                                clientVersion = p.expectedRevision
                            )
                            if (res.isSuccess) {
                                pendingSyncDao.removeByOperationId(p.operationId)
                                noteDao.getNoteById(p.noteId)?.let { currentNote ->
                                    noteDao.insertOrUpdate(currentNote.copy(syncStatus = "SYNCED"))
                                }
                            }
                        }
                        "DELETE" -> {
                            val res = apiService.trashNote(p.noteId)
                            if (res.isSuccess || (res.exceptionOrNull() as? ApiErrorDetail)?.statusCode == 404) {
                                pendingSyncDao.removeByOperationId(p.operationId)
                            }
                        }
                    }
                } catch (_: Exception) {}
            }

            // Step 2: Fetch remote changes via /v1/sync/changes
            val changesRes = apiService.getSyncChanges(since = sessionManager.lastSyncTimestamp)
            if (changesRes.isSuccess) {
                val changes = changesRes.getOrThrow()
                for (item in changes.items) {
                    if (item.deleted) {
                        noteDao.softDelete(item.noteId, getCurrentIsoTime())
                    } else {
                        val decryptedJson = keystoreHelper.decryptText(item.encryptedPayload, item.nonce)
                        val unpacked = keystoreHelper.unpackNotePayload(decryptedJson)
                        val existingLocal = noteDao.getNoteById(item.noteId)
                        val updatedLocal = NoteDbEntity(
                            id = item.noteId,
                            revision = maxOf(item.clientVersion, existingLocal?.revision ?: 1L),
                            serverVersion = item.serverVersion,
                            titleCiphertext = item.encryptedPayload,
                            contentCiphertext = item.encryptedPayload,
                            decryptedTitleCache = unpacked.title.ifBlank { "Encrypted Note" },
                            decryptedContentCache = unpacked.content,
                            tagsCiphertext = null,
                            decryptedTagsCache = unpacked.tags,
                            encryptionNonce = item.nonce,
                            folder = unpacked.folder,
                            colorHex = unpacked.colorHex,
                            isPinned = unpacked.isPinned,
                            isFavorite = unpacked.isFavorite,
                            isDeleted = false,
                            deletedAt = null,
                            createdAt = existingLocal?.createdAt ?: getCurrentIsoTime(),
                            updatedAt = getCurrentIsoTime(),
                            syncStatus = "SYNCED"
                        )
                        noteDao.insertOrUpdate(updatedLocal)
                    }
                }
                sessionManager.lastSyncTimestamp = changes.serverTime
            } else {
                // Reconciliation fallback: list active notes from /v1/notes
                val listRes = apiService.listNotes(limit = 50)
                if (listRes.isSuccess) {
                    val (remoteNotes, _) = listRes.getOrThrow()
                    for (item in remoteNotes) {
                        val existingLocal = noteDao.getNoteById(item.noteId)
                        if (existingLocal == null || existingLocal.serverVersion < item.serverVersion) {
                            val decryptedJson = keystoreHelper.decryptText(item.encryptedPayload, item.nonce)
                            val unpacked = keystoreHelper.unpackNotePayload(decryptedJson)
                            val noteDb = NoteDbEntity(
                                id = item.noteId,
                                revision = item.clientVersion,
                                serverVersion = item.serverVersion,
                                titleCiphertext = item.encryptedPayload,
                                contentCiphertext = item.encryptedPayload,
                                decryptedTitleCache = unpacked.title.ifBlank { "Encrypted Note" },
                                decryptedContentCache = unpacked.content,
                                tagsCiphertext = null,
                                decryptedTagsCache = unpacked.tags,
                                encryptionNonce = item.nonce,
                                folder = unpacked.folder,
                                colorHex = unpacked.colorHex,
                                isPinned = unpacked.isPinned,
                                isFavorite = unpacked.isFavorite,
                                isDeleted = false,
                                deletedAt = null,
                                createdAt = existingLocal?.createdAt ?: getCurrentIsoTime(),
                                updatedAt = getCurrentIsoTime(),
                                syncStatus = "SYNCED"
                            )
                            noteDao.insertOrUpdate(noteDb)
                        }
                    }
                }
            }

            Result.success("All notes encrypted and synced with FastAPI CloudMemo Server.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createShare(noteId: String, recipientEmail: String, permission: String): Result<ShareItemDto> {
        val share = ShareItemDto(
            shareId = "share_" + System.currentTimeMillis(),
            noteId = noteId,
            recipientEmail = recipientEmail,
            permission = permission,
            createdAt = "Just now"
        )
        return Result.success(share)
    }

    suspend fun listShares(noteId: String): Result<List<ShareItemDto>> {
        return Result.success(emptyList())
    }

    suspend fun revokeShare(shareId: String): Result<Boolean> {
        return Result.success(true)
    }
}
