package com.example.data.model

data class NoteEntity(
    val id: String,
    val revision: Long = 1L,
    val serverVersion: Long = 1L,
    val titleCiphertext: String = "",
    val contentCiphertext: String = "",
    val decryptedTitleCache: String = "",
    val decryptedContentCache: String = "",
    val tagsCiphertext: String? = null,
    val decryptedTagsCache: String = "",
    val encryptionNonce: String = "",
    val encryptionKeyId: String = "AndroidKeyStore:cloudmemo_notes_master_key",
    val encryptionAlgorithm: String = "AES-256-GCM",
    val encryptionVersion: Int = 1,
    val folder: String = "Personal",
    val colorHex: String = "#00F5D4",
    val isPinned: Boolean = false,
    val isFavorite: Boolean = false,
    val isDeleted: Boolean = false,
    val deletedAt: String? = null,
    val createdAt: String = "",
    val updatedAt: String = "",
    val syncStatus: String = "SYNCED"
)

data class UnpackedNote(
    val title: String,
    val content: String,
    val tags: String,
    val folder: String,
    val colorHex: String,
    val isPinned: Boolean,
    val isFavorite: Boolean
)

data class PendingSyncEntity(
    val operationId: String,
    val noteId: String,
    val type: String, // CREATE, UPDATE, DELETE
    val expectedRevision: Long,
    val titleCiphertext: String? = null,
    val contentCiphertext: String? = null,
    val tagsCiphertext: String? = null,
    val nonce: String? = null,
    val keyId: String? = null,
    val folder: String? = null,
    val colorHex: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val retryCount: Int = 0
)

data class UserProfileDto(
    val id: String,
    val email: String,
    val displayName: String,
    val role: String,
    val status: String = "active",
    val emailVerified: Boolean = false,
    val createdAt: Long = 0L
)

data class AuthResponseDto(
    val accessToken: String,
    val tokenType: String,
    val expiresIn: Long,
    val user: UserProfileDto
)

data class RegisterResponseDto(
    val message: String,
    val expiresInSeconds: Long = 600L
)

data class NoteServerItemDto(
    val noteId: String,
    val encryptedPayload: String,
    val nonce: String,
    val keyVersion: Int = 1,
    val clientVersion: Long = 1L,
    val serverVersion: Long = 1L,
    val titleHint: String? = null,
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
    val deleted: Boolean = false,
    val deletedAt: Long? = null
)

data class TrashServerItemDto(
    val noteId: String,
    val deletedAt: Long = 0L,
    val updatedAt: Long = 0L
)

data class SyncChangesResponseDto(
    val items: List<NoteServerItemDto>,
    val serverTime: Long
)

data class DeviceDto(
    val deviceId: String,
    val deviceName: String,
    val deviceType: String,
    val lastSeenAt: String,
    val isCurrent: Boolean = false,
    val revoked: Boolean = false
)

data class ShareItemDto(
    val shareId: String,
    val noteId: String,
    val recipientEmail: String,
    val permission: String, // READ, READ_WRITE
    val createdAt: String
)

data class AccountExportDto(
    val format: String,
    val exportedAt: Long,
    val userEmail: String,
    val userDisplayName: String,
    val rawJson: String
)

class ApiErrorDetail(
    val statusCode: Int,
    override val message: String,
    val isConflict: Boolean = false,
    val serverVersion: Long? = null,
    val clientVersion: Long? = null
) : Exception(message)
