package com.example.data.network

import android.content.Context
import android.content.SharedPreferences

class SessionManager(context: Context) {

    companion object {
        private const val PREFS_NAME = "cloudmemo_session_prefs"
        private const val KEY_AUTH_TOKEN = "auth_token"
        private const val KEY_USER_EMAIL = "user_email"
        private const val KEY_USER_DISPLAY_NAME = "user_display_name"
        private const val KEY_USER_ID = "user_id"
        private const val KEY_USER_ROLE = "user_role"
        private const val KEY_TOKEN_EXPIRES_AT = "token_expires_at"
        private const val KEY_SERVER_URL = "server_url"
        private const val KEY_AUTO_SYNC = "auto_sync"
        private const val KEY_THEME_MODE = "theme_mode"
        private const val KEY_LAST_SYNC_TIME = "last_sync_time"

        private const val KEY_ACCEPTED_TOS_VERSION = "accepted_tos_version"
        private const val KEY_NOTE_DISPLAY_LAYOUT = "note_display_layout"

        const val CURRENT_TOS_VERSION = "cloudmemo-tos-v1"
        const val DEFAULT_BASE_URL = "https://notpad.wisp.uno"
    }

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var acceptedTosVersion: String?
        get() = prefs.getString(KEY_ACCEPTED_TOS_VERSION, null)
        set(value) = prefs.edit().putString(KEY_ACCEPTED_TOS_VERSION, value).apply()

    val isTosAccepted: Boolean
        get() = acceptedTosVersion == CURRENT_TOS_VERSION

    fun acceptTos(version: String = CURRENT_TOS_VERSION) {
        acceptedTosVersion = version
    }

    fun resetTos() {
        prefs.edit().remove(KEY_ACCEPTED_TOS_VERSION).apply()
    }

    var noteDisplayLayout: String
        get() = prefs.getString(KEY_NOTE_DISPLAY_LAYOUT, "GRID_VIEW") ?: "GRID_VIEW"
        set(value) = prefs.edit().putString(KEY_NOTE_DISPLAY_LAYOUT, value).apply()

    var authToken: String?
        get() = prefs.getString(KEY_AUTH_TOKEN, null)
        set(value) = prefs.edit().putString(KEY_AUTH_TOKEN, value).apply()

    var userEmail: String?
        get() = prefs.getString(KEY_USER_EMAIL, null)
        set(value) = prefs.edit().putString(KEY_USER_EMAIL, value).apply()

    var userDisplayName: String?
        get() = prefs.getString(KEY_USER_DISPLAY_NAME, null)
        set(value) = prefs.edit().putString(KEY_USER_DISPLAY_NAME, value).apply()

    var userId: String?
        get() = prefs.getString(KEY_USER_ID, null)
        set(value) = prefs.edit().putString(KEY_USER_ID, value).apply()

    var userRole: String?
        get() = prefs.getString(KEY_USER_ROLE, "user")
        set(value) = prefs.edit().putString(KEY_USER_ROLE, value).apply()

    var tokenExpiresAt: Long
        get() = prefs.getLong(KEY_TOKEN_EXPIRES_AT, 0L)
        set(value) = prefs.edit().putLong(KEY_TOKEN_EXPIRES_AT, value).apply()

    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, DEFAULT_BASE_URL) ?: DEFAULT_BASE_URL
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value).apply()

    var isAutoSyncEnabled: Boolean
        get() = prefs.getBoolean(KEY_AUTO_SYNC, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_SYNC, value).apply()

    var themeMode: String
        get() = prefs.getString(KEY_THEME_MODE, "OBSIDIAN_CRYSTAL") ?: "OBSIDIAN_CRYSTAL"
        set(value) = prefs.edit().putString(KEY_THEME_MODE, value).apply()

    var lastSyncTimestamp: Long
        get() = prefs.getLong(KEY_LAST_SYNC_TIME, 0L)
        set(value) = prefs.edit().putLong(KEY_LAST_SYNC_TIME, value).apply()

    val isTokenExpired: Boolean
        get() = tokenExpiresAt > 0 && System.currentTimeMillis() >= tokenExpiresAt

    val isLoggedIn: Boolean
        get() = !authToken.isNullOrBlank() && !isTokenExpired

    val isSessionValid: Boolean
        get() = isLoggedIn

    fun saveAuth(token: String, email: String, displayName: String, id: String, role: String, expiresInSeconds: Long) {
        val expiresAt = System.currentTimeMillis() + (expiresInSeconds * 1000L)
        prefs.edit()
            .putString(KEY_AUTH_TOKEN, token)
            .putString(KEY_USER_EMAIL, email)
            .putString(KEY_USER_DISPLAY_NAME, displayName)
            .putString(KEY_USER_ID, id)
            .putString(KEY_USER_ROLE, role)
            .putLong(KEY_TOKEN_EXPIRES_AT, expiresAt)
            .apply()
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_AUTH_TOKEN)
            .remove(KEY_USER_EMAIL)
            .remove(KEY_USER_DISPLAY_NAME)
            .remove(KEY_USER_ID)
            .remove(KEY_USER_ROLE)
            .remove(KEY_TOKEN_EXPIRES_AT)
            .apply()
    }
}
