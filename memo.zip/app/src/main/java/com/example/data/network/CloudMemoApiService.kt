package com.example.data.network

import com.example.data.model.AccountExportDto
import com.example.data.model.ApiErrorDetail
import com.example.data.model.AuthResponseDto
import com.example.data.model.DeviceDto
import com.example.data.model.NoteServerItemDto
import com.example.data.model.RegisterResponseDto
import com.example.data.model.SyncChangesResponseDto
import com.example.data.model.TrashServerItemDto
import com.example.data.model.UserProfileDto
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class CloudMemoApiService(private val sessionManager: SessionManager) {

    companion object {
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private fun baseUrl(): String {
        return sessionManager.serverUrl.trimEnd('/')
    }

    private fun parseError(response: Response): ApiErrorDetail {
        val code = response.code
        val bodyStr = try { response.body?.string().orEmpty() } catch (_: Exception) { "" }
        var message = "Request failed with status $code"
        var isConflict = false
        var serverVer: Long? = null
        var clientVer: Long? = null

        if (bodyStr.isNotBlank()) {
            try {
                val root = JSONObject(bodyStr)
                when (val detailOpt = root.opt("detail")) {
                    is String -> {
                        message = detailOpt
                    }
                    is JSONArray -> {
                        val messages = mutableListOf<String>()
                        for (i in 0 until detailOpt.length()) {
                            val item = detailOpt.optJSONObject(i)
                            val msg = item?.optString("msg")
                            if (!msg.isNullOrBlank()) messages.add(msg)
                        }
                        if (messages.isNotEmpty()) {
                            message = messages.joinToString("; ")
                        }
                    }
                    is JSONObject -> {
                        message = detailOpt.optString("message", "Conflict or validation error")
                        if (detailOpt.has("server_version")) {
                            isConflict = true
                            serverVer = detailOpt.optLong("server_version")
                            clientVer = detailOpt.optLong("client_version")
                        }
                    }
                }
            } catch (_: Exception) {
                if (bodyStr.length < 200) {
                    message = bodyStr
                }
            }
        }

        if (code == 401 && (message.contains("status 401") || message.contains("Unauthorized"))) {
            message = "Invalid email/password or session expired."
        } else if (code == 403 && message.contains("status 403")) {
            message = "Email verification required or account restricted."
        } else if (code == 409 && message.contains("status 409")) {
            message = "Duplicate resource or version conflict."
            isConflict = true
        } else if (code == 429) {
            if (message.contains("status 429")) {
                message = "Too many requests. Please wait a moment before trying again."
            }
        }

        return ApiErrorDetail(
            statusCode = code,
            message = message,
            isConflict = isConflict,
            serverVersion = serverVer,
            clientVersion = clientVer
        )
    }

    suspend fun register(
        email: String,
        password: String,
        displayName: String
    ): Result<RegisterResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/register"
            val json = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
                put("display_name", displayName.trim())
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code == 202 || response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = if (body.isNotBlank()) JSONObject(body) else JSONObject()
                    val msg = obj.optString("message", "Verification code sent")
                    val expires = obj.optLong("expires_in_seconds", 600L)
                    Result.success(RegisterResponseDto(msg, expires))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun verifyEmail(
        email: String,
        code: String
    ): Result<AuthResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/verify-email"
            val json = JSONObject().apply {
                put("email", email.trim())
                put("code", code.trim())
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val token = obj.getString("access_token")
                    val tokenType = obj.optString("token_type", "bearer")
                    val expiresIn = obj.optLong("expires_in", 3600L)
                    val userObj = obj.getJSONObject("user")
                    val user = UserProfileDto(
                        id = userObj.getString("id"),
                        email = userObj.getString("email"),
                        displayName = userObj.optString("display_name", ""),
                        role = userObj.optString("role", "user"),
                        emailVerified = true
                    )
                    sessionManager.saveAuth(token, user.email, user.displayName, user.id, user.role, expiresIn)
                    Result.success(AuthResponseDto(token, tokenType, expiresIn, user))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun resendCode(email: String): Result<RegisterResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/resend-code"
            val json = JSONObject().apply {
                put("email", email.trim())
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code == 202 || response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = if (body.isNotBlank()) JSONObject(body) else JSONObject()
                    val msg = obj.optString("message", "Verification code resent")
                    val expires = obj.optLong("expires_in_seconds", 600L)
                    Result.success(RegisterResponseDto(msg, expires))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun login(
        email: String,
        password: String,
        deviceName: String
    ): Result<AuthResponseDto> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl()}/v1/auth/login"
            val json = JSONObject().apply {
                put("email", email.trim())
                put("password", password)
                put("device_name", deviceName.ifBlank { "Android Device" })
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val token = obj.getString("access_token")
                    val tokenType = obj.optString("token_type", "bearer")
                    val expiresIn = obj.optLong("expires_in", 3600L)
                    val userObj = obj.getJSONObject("user")
                    val user = UserProfileDto(
                        id = userObj.getString("id"),
                        email = userObj.getString("email"),
                        displayName = userObj.optString("display_name", ""),
                        role = userObj.optString("role", "user"),
                        emailVerified = true
                    )
                    sessionManager.saveAuth(token, user.email, user.displayName, user.id, user.role, expiresIn)
                    Result.success(AuthResponseDto(token, tokenType, expiresIn, user))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getCurrentUser(): Result<UserProfileDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/me"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val user = UserProfileDto(
                        id = obj.getString("id"),
                        email = obj.getString("email"),
                        displayName = obj.optString("display_name", ""),
                        role = obj.optString("role", "user"),
                        status = obj.optString("status", "active"),
                        emailVerified = obj.optBoolean("email_verified", true),
                        createdAt = obj.optLong("created_at", 0L)
                    )
                    sessionManager.userEmail = user.email
                    sessionManager.userDisplayName = user.displayName
                    sessionManager.userId = user.id
                    sessionManager.userRole = user.role
                    Result.success(user)
                } else {
                    if (response.code == 401) {
                        sessionManager.clearSession()
                    }
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createNote(
        noteId: String,
        encryptedPayload: String,
        nonce: String,
        keyVersion: Int = 1,
        clientVersion: Long = 1L
    ): Result<NoteServerItemDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes"
            val json = JSONObject().apply {
                put("note_id", noteId)
                put("encrypted_payload", encryptedPayload)
                put("nonce", nonce)
                put("key_version", keyVersion)
                put("client_version", clientVersion)
                put("title_hint", JSONObject.NULL)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.code == 201 || response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    Result.success(
                        NoteServerItemDto(
                            noteId = obj.getString("note_id"),
                            encryptedPayload = encryptedPayload,
                            nonce = nonce,
                            keyVersion = keyVersion,
                            clientVersion = clientVersion,
                            serverVersion = obj.optLong("server_version", 1L),
                            updatedAt = obj.optLong("updated_at", System.currentTimeMillis() / 1000L)
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun listNotes(limit: Int = 50, cursor: String? = null): Result<Pair<List<NoteServerItemDto>, String?>> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            var url = "${baseUrl()}/v1/notes?limit=$limit"
            if (!cursor.isNullOrBlank()) {
                url += "&cursor=$cursor"
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val items = mutableListOf<NoteServerItemDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        items.add(
                            NoteServerItemDto(
                                noteId = item.getString("note_id"),
                                encryptedPayload = item.getString("encrypted_payload"),
                                nonce = item.getString("nonce"),
                                keyVersion = item.optInt("key_version", 1),
                                clientVersion = item.optLong("client_version", 1L),
                                serverVersion = item.optLong("server_version", 1L),
                                titleHint = if (item.isNull("title_hint")) null else item.optString("title_hint"),
                                createdAt = item.optLong("created_at", 0L),
                                updatedAt = item.optLong("updated_at", 0L)
                            )
                        )
                    }
                    val nextCursor = if (obj.isNull("next_cursor")) null else obj.optString("next_cursor")
                    Result.success(Pair(items, nextCursor))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getNote(noteId: String): Result<NoteServerItemDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes/$noteId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val item = JSONObject(body)
                    Result.success(
                        NoteServerItemDto(
                            noteId = item.getString("note_id"),
                            encryptedPayload = item.getString("encrypted_payload"),
                            nonce = item.getString("nonce"),
                            keyVersion = item.optInt("key_version", 1),
                            clientVersion = item.optLong("client_version", 1L),
                            serverVersion = item.optLong("server_version", 1L),
                            titleHint = if (item.isNull("title_hint")) null else item.optString("title_hint"),
                            createdAt = item.optLong("created_at", 0L),
                            updatedAt = item.optLong("updated_at", 0L)
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateNote(
        noteId: String,
        encryptedPayload: String,
        nonce: String,
        keyVersion: Int = 1,
        clientVersion: Long
    ): Result<NoteServerItemDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes/$noteId"
            val json = JSONObject().apply {
                put("encrypted_payload", encryptedPayload)
                put("nonce", nonce)
                put("key_version", keyVersion)
                put("client_version", clientVersion)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .put(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    Result.success(
                        NoteServerItemDto(
                            noteId = obj.getString("note_id"),
                            encryptedPayload = encryptedPayload,
                            nonce = nonce,
                            keyVersion = keyVersion,
                            clientVersion = clientVersion,
                            serverVersion = obj.optLong("server_version", clientVersion),
                            updatedAt = obj.optLong("updated_at", System.currentTimeMillis() / 1000L)
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun trashNote(noteId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/notes/$noteId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun listTrash(): Result<List<TrashServerItemDto>> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/trash"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val list = mutableListOf<TrashServerItemDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        list.add(
                            TrashServerItemDto(
                                noteId = item.getString("note_id"),
                                deletedAt = item.optLong("deleted_at", 0L),
                                updatedAt = item.optLong("updated_at", 0L)
                            )
                        )
                    }
                    Result.success(list)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun restoreTrashNote(noteId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/trash/$noteId/restore"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .post("{}".toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun permanentDeleteTrashNote(noteId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/trash/$noteId/permanent"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getSyncChanges(since: Long = 0L, limit: Int = 100): Result<SyncChangesResponseDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/sync/changes?since=$since&limit=$limit"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val items = mutableListOf<NoteServerItemDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        items.add(
                            NoteServerItemDto(
                                noteId = item.getString("note_id"),
                                encryptedPayload = item.optString("encrypted_payload", ""),
                                nonce = item.optString("nonce", ""),
                                keyVersion = item.optInt("key_version", 1),
                                clientVersion = item.optLong("client_version", 1L),
                                serverVersion = item.optLong("server_version", 1L),
                                titleHint = if (item.isNull("title_hint")) null else item.optString("title_hint"),
                                createdAt = item.optLong("created_at", 0L),
                                updatedAt = item.optLong("updated_at", 0L),
                                deleted = item.optBoolean("deleted", false),
                                deletedAt = if (item.isNull("deleted_at")) null else item.optLong("deleted_at")
                            )
                        )
                    }
                    val serverTime = obj.optLong("server_time", System.currentTimeMillis() / 1000L)
                    Result.success(SyncChangesResponseDto(items, serverTime))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun registerDevice(
        deviceId: String,
        deviceName: String,
        publicKey: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/devices"
            val json = JSONObject().apply {
                put("device_id", deviceId)
                put("device_name", deviceName)
                put("public_key", publicKey)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .post(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    Result.success(obj.optString("device_record_id", deviceId))
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun listDevices(): Result<List<DeviceDto>> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/devices"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val itemsArr = obj.optJSONArray("items") ?: JSONArray()
                    val currentDevId = sessionManager.userEmail?.hashCode()?.toString()
                    val list = mutableListOf<DeviceDto>()
                    for (i in 0 until itemsArr.length()) {
                        val item = itemsArr.getJSONObject(i)
                        val devId = item.getString("device_id")
                        val devName = item.optString("device_name", "Device")
                        val created = item.optLong("created_at", 0L)
                        val lastSeen = item.optLong("last_seen_at", 0L)
                        val revoked = item.optBoolean("revoked", false)
                        list.add(
                            DeviceDto(
                                deviceId = devId,
                                deviceName = devName,
                                deviceType = if (devName.contains("Android", true)) "Mobile" else "Client",
                                lastSeenAt = if (lastSeen > 0) "Last seen ${java.text.SimpleDateFormat("MMM dd, HH:mm", java.util.Locale.US).format(java.util.Date(lastSeen * 1000L))}" else "Active",
                                isCurrent = devId == currentDevId || i == 0,
                                revoked = revoked
                            )
                        )
                    }
                    Result.success(list)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun revokeDevice(deviceId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/devices/$deviceId"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun exportAccount(): Result<AccountExportDto> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/account/export"
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    val body = response.body?.string().orEmpty()
                    val obj = JSONObject(body)
                    val userObj = obj.optJSONObject("user")
                    Result.success(
                        AccountExportDto(
                            format = obj.optString("format", "cloudmemo-export-v1"),
                            exportedAt = obj.optLong("exported_at", System.currentTimeMillis() / 1000L),
                            userEmail = userObj?.optString("email", sessionManager.userEmail.orEmpty()).orEmpty(),
                            userDisplayName = userObj?.optString("display_name", sessionManager.userDisplayName.orEmpty()).orEmpty(),
                            rawJson = body
                        )
                    )
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteAccount(password: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val token = sessionManager.authToken ?: return@withContext Result.failure(Exception("Not authenticated"))
            val url = "${baseUrl()}/v1/account"
            val json = JSONObject().apply {
                put("password", password)
            }
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $token")
                .delete(json.toString().toRequestBody(JSON_MEDIA_TYPE))
                .build()

            client.newCall(request).execute().use { response ->
                if (response.isSuccessful) {
                    sessionManager.clearSession()
                    Result.success(true)
                } else {
                    Result.failure(parseError(response))
                }
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
